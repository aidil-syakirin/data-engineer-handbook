MEDIUM KPI AND EXPERIMENTATION

instead of product that I loved to use, I will pick the product that I see maybe some experimentation can be done. It is Medium, an app for article sharing. 

I initially registered for this app to increase my daily word count and try to gain unexpected and new knowledge. i really loved the daily articles compilation newsletter as it always remind me to read atleast 1 article a day.

Experiment 1: Free Article Filter features introduction

Objective: The industry standard is paid users percentage is less than 5% and a lot of the crowd usually free users. Currently, the apps homepage has only list of topics that users specified and as the ratio of paid and free articles quite large, I found myself always scrolling for a min to find any readable article. The feature will filter out the paid articles and will provide a better experience for users.

Null hypothesis: Free articles filter will increase the user daily visits frequency and time spent on apps

Alternative hypothesis: Free articles filter will has no impact on the user daily visits frequency and time spent on apps

Leading Metric: User daily visits, time spend

Lagging Metric: Paid users conversation rate

The test cell will be 50% as control, another 25% of free users and rest of 25% of paid users. 

Experiment 2: Gamification of the apps

Objective: The idea of gamification of apps is already norm. Medium will be introducing some daily check-in feature for tracking users activity and rewarding login and minimum time spent on the apps with some sort of in-apps currency. The currency can be used to redeem paid articles or a month of subscription. This will be tested on users of early career people (20-30s) or high school age. 

Null hypothesis: This feature will attract the specified age users and will increase the daily visits and time spend on apps. It will also may increase the conversion rate as the users may subscribe if they visit daily and find themselves interested in paywall articles.

Alternative hypothesis: This feature will not much impact the user experience 

Test cell will be 20% as a control, and split the rest to 4 bucket of 20% of different age ranges. 

Experiment 3: Changing Sign-Up Ads to Enhance User Engagement

Objective: To determine whether changing the sign-up ad from "Save up to $XX for annual subscription" to "Get free 2 months when you subscribe for a year" positively impacts user sign-up rates and engagement on the platform.

Null Hypothesis: There is no significant difference in user sign-up rates between the "Save up to $XX for annual subscription" to "Get free 2 months when you subscribe for a year" ad variations.

Alternative Hypothesis: Users who see the "Get free 2 months when you subscribe for a year" ad will have a significantly higher sign-up rate compared to those who see the "Save up to $XX for annual subscription" ad.

Leading metrics: the amount of time users spend on app after signing up.

Lagging metrics: the percentage of users who convert from free to premium subscribers after signing up.

Test cell allocation: 50%-50%